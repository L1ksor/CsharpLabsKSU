﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpControlWork1
{
    class Edition
    {
        protected string _title;
        protected DateTime _releaseData;
        protected int _pressrun;



        public Edition(string edition, DateTime releaseDataEdition, int pressrun)
        {
            _title = edition;
            _releaseData = releaseDataEdition;
            _pressrun = pressrun;
        }

        public Edition() 
        {
            _title = default(string);
            _releaseData= default(DateTime);
            _pressrun = default(int);
        }


    }
}
