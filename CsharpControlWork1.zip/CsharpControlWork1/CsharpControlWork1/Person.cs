﻿namespace CsharpControlWork1
{
    public class Person
    {
    }
}